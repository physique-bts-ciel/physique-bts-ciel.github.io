# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
from math import pi, sqrt

N = 4000                        # Nombre de points
f = 110
T = 1/f
w = 2*pi*f
t = np.linspace(0,T,N)          # tps en milliseconde
u = np.zeros(N,np.double)      # Tension


A   = np.array([1.8, 5.0,  2.0,  1.5,  1.0,  0.5])
phi = [0.0, 0.0, -0.3, +0.6, -0.7, +1.2]

n = 2  # Nombre de périodes

u = ( A[0] +
      A[1]*np.sin(1*n*w*t + phi[1]) +
      A[2]*np.sin(2*n*w*t + phi[2]) +
      A[3]*np.sin(3*n*w*t + phi[3]) +
      A[4]*np.sin(4*n*w*t + phi[4]) +
      A[5]*np.sin(5*n*w*t + phi[5])
    )


moy = np.average(u)         # Calcul valeur moyenne
eff = sqrt(np.mean(u**2))   # Calcul valeur efficace
print("<u> =" , moy, "U = ", eff)



plt.plot(t*1000, u)
plt.axhline(0,color="black")
plt.title("")
plt.xlabel("t (ms)")
plt.ylabel("u (V)")
plt.grid()

plt.savefig("signal_TP2.png")
plt.show()


###### Export Siglent GBF  ############
data_length = N
frequency = f
amp = max(u)*2             # Tension max VPP (crête à crête)
offset = 0                 # Offset
phase = 0

if amp>20: print("Amplitude {} hors échelle !!!".format(amp))

fichier = open("signal_TP2.csv", "w")
fichier.write("data length,{}\n".format(data_length))
fichier.write("frequency,{:.9f}\n".format(frequency))
fichier.write("amp,{:.9f}\n".format(amp))
fichier.write("offset,{:.9f}\n".format(offset))
fichier.write("phase,{:.9f}\n".format(phase))
for i in range(7):
    fichier.write("\n")
fichier.write("xpos,value\n")
for i in range(len(t)):
    fichier.write("{:.5e},{:.5e}\n".format(t[i], u[i]))
fichier.close()


