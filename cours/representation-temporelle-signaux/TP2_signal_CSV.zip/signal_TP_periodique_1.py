import numpy as np
import matplotlib.pyplot as plt
from math import pi, sqrt

##### PARAMETRES #####
N = 1200      # Nombre de points pour une période
T = 1.2E-3     # Période du signal
f = 1/T       # Fréquence du signal
nb = 3        # Nombre de périodes à générer

##### SYNTHESE DU SIGNAL #####
t = np.linspace(0, nb*T, nb*N)        # tps en milliseconde


u1 = [4 for i in range(500)]  
u2 = [8 for n in range(300)]
u3 = [-5 for i in range(400)]  

u = np.array((u1+u2+u3)*nb)

moy = np.average(u)         # Calcul valeur moyenne
eff = sqrt(np.mean(u**2))   # Calcul valeur efficace
print("f = ", f, "\t<u> =" , moy, "\tU = ", eff)


###### COURBES #######
#plt.axhspan(-10,+10, color="orange", alpha=0.2)
plt.plot(t*1E3, u)
#plt.plot(t*1E3, u-moy)
plt.axhline(0,color="black")
plt.xlabel("t (ms)")
plt.xlim(0,3.6)
plt.ylabel("u (V)")
plt.ylim(-6,10)
plt.grid()
plt.savefig("signal_TP_periodique_1.png")
plt.show()


##### Export Siglent GBF  #####
data_length = N*nb
frequency = f/nb
amp = max(u)*2             # Tension max VPP (crête à crête)
offset = 0                 # Offset
phase = 0

if amp<=20:  # Limitation du GBF à 20 VPP
    fichier = open("signal_1.csv", "w")
    fichier.write("data length,{}\n".format(data_length))
    fichier.write("frequency,{:.9f}\n".format(frequency))
    fichier.write("amp,{:.9f}\n".format(amp))
    fichier.write("offset,{:.9f}\n".format(offset))
    fichier.write("phase,{:.9f}\n".format(phase))
    for i in range(7):
        fichier.write("\n")
    fichier.write("xpos,value\n")
    for i in range(len(t)):
        fichier.write("{:.5e},{:.5e}\n".format(t[i], u[i]))
    fichier.close()
else:
    print("Pas d'exportation en CSV : amplitude supérieure à 20 VPP !")


